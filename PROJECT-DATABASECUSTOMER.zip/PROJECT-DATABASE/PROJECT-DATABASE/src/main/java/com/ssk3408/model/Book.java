package com.ssk3408.model;

public class Book {

	String productCode;
	String quantityBooked;	
	String customerId;
	
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getQuantityBooked() {
		return quantityBooked;
	}
	public void setQuantityBooked(String quantityBooked) {
		this.quantityBooked = quantityBooked;
	}


}
