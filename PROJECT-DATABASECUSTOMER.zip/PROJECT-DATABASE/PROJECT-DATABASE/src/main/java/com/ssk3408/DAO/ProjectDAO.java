package com.ssk3408.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.ssk3408.model.Book;
import com.ssk3408.model.Customer;
import com.ssk3408.model.Product;

public class ProjectDAO {

		Connection connection = null;
		Statement statement = null;
		ResultSet resultSet = null;
		PreparedStatement preparedStatement = null;

		public boolean save(Customer u) {
			boolean flag = false;

			try {
				String sql = "INSERT INTO customer(CUSTOMERID, CUSTOMERPHONENO, CUSTOMERNAME, CUSTOMEREMAILADDRESS ,CUSTOMERPASSWORD)"
						+ "VALUES" + "('"+ u.getCustomerId() + "','" + u.getCustomerPhoneNo() + "', '" + u.getCustomerName() + "', '" + u.getCustomerEmailAddress()+
						"','" + u.getCustomerPassword() + "')";
				System.out.println(sql);
				connection = DBConnectionUtil.openConnection();
				preparedStatement = connection.prepareStatement(sql);
				preparedStatement.executeUpdate();
				flag = true;
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
			return flag;
		}

		public List<Customer> getCustomer() {
			List<Customer> list = null;
			Customer customer = new Customer();

			try {
				list = new ArrayList<Customer>();
				String sql = "SELECT * FROM PRODUCT order by customerid asc";
				connection = DBConnectionUtil.openConnection();
				statement = connection.createStatement();
				resultSet = statement.executeQuery(sql);

				while (resultSet.next()) {
					customer = new Customer();
					customer.setCustomerId(resultSet.getString("customerId"));
					customer.setCustomerPhoneNo(resultSet.getString("customerPhoneNo"));
					customer.setCustomerName(resultSet.getString("customerName"));
					customer.setCustomerEmailAddress(resultSet.getString("customerEmailAddress"));
					customer.setCustomerPassword(resultSet.getString("customerPassword"));
					list.add(customer);
				}
			} catch (Exception e) {
			}

			return list;
		}
		
		public boolean checkCustomer(String customerId) {
			Boolean found = false;
			try {
			String sql = "SELECT * FROM customer where customerId='" + customerId +"'";
			connection = DBConnectionUtil.openConnection();
			statement = connection.createStatement();
			resultSet = statement.executeQuery(sql);
			if (resultSet.next()) {
			found = true;
			}
			} catch (SQLException e) {
			e.printStackTrace();
			}
			return found;
			}

		public List<Product> getProduct() {
			List<Product> list = null;
			Product product = new Product();

			try {
			list = new ArrayList<Product>();
			String sql = "SELECT * FROM product order by productCode asc";
			connection = DBConnectionUtil.openConnection();
			statement = connection.createStatement();
			resultSet = statement.executeQuery(sql);

			while (resultSet.next()) {
			product = new Product();
			product.setProductCode(resultSet.getString("productCode"));
			product.setProductName(resultSet.getString("productName"));
			product.setProductType(resultSet.getString("productType"));
			product.setPrice(resultSet.getString("price"));
			product.setQuantity(resultSet.getString("quantity"));
			list.add(product);
			}
			} catch (Exception e) {
			}
			return list;
			}
		public boolean checkCustomerPass(String customerPassword) {
			Boolean found = false;
			try {
			String sql = "SELECT * FROM customer where customerPassword='" + customerPassword +"'";
			connection = DBConnectionUtil.openConnection();
			statement = connection.createStatement();
			resultSet = statement.executeQuery(sql);
			if (resultSet.next()) {
			found = true;
			}
			} catch (SQLException e) {
			e.printStackTrace();
			}
			return found;
			}
		public boolean saveBook(Book b) {
			boolean flag = false;

			try {
				String sql = "INSERT INTO PRODUCTBOOKED(CUSTOMERID, PRODUCTCODE, QUANTITYBOOKED)"
						+ "VALUES" + "('"+ b.getCustomerId() + "','" + b.getProductCode()+
						"','" + b.getQuantityBooked() + "')";
				System.out.println(sql);
				connection = DBConnectionUtil.openConnection();
				preparedStatement = connection.prepareStatement(sql);
				preparedStatement.executeUpdate();
				flag = true;
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
			return flag;
		}
	}