package com.ssk3408;

import java.io.IOException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.ssk3408.DAO.ProjectDAO;
import com.ssk3408.model.Book;
import com.ssk3408.model.Customer;
import com.ssk3408.model.Product;

public class ProjectController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ProjectDAO proDAO = null;
	RequestDispatcher rd = null;
	String clickDelete = "";
	String clickUpdate = "";
	String clickLogin = "";

	public ProjectController() {
		proDAO = new ProjectDAO();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
		String action = request.getParameter("action");
		switch (action) {
		case "signUp":
			rd = request.getRequestDispatcher("/SignUp.jsp");
			rd.forward(request, response);
			break;
		case "login":
			rd = request.getRequestDispatcher("/login.jsp");
			rd.forward(request, response);
			break;
		case "MAINMENU":
			listProduct(request,response);
			break;
		case "BOOK":
			rd = request.getRequestDispatcher("/productBook.jsp");
			rd.forward(request, response);
		default:
			listCustomer(request, response);
			break;
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getParameter("action");
		switch (action) {
		case "signUp":
			saveCustomer(request, response);
			break;
		case "LOGIN":
			getSingleCustomerLogin(request,response);
			break;
		case "ADDBOOKED":
			saveBookCustomer(request,response);
		default:
			listCustomer(request, response);
			break;
		}
	}

	protected void getSingleCustomerLogin(HttpServletRequest request, HttpServletResponse response) 
		throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());

		if (clickLogin == "") {
			String customerId = request.getParameter("customerId");
			boolean userFound = proDAO.checkCustomer(customerId);

			if (userFound) {
			String customerPassword = request.getParameter("customerPassword");
			boolean userFound2 = proDAO.checkCustomerPass(customerPassword);
			if(userFound2) {
				rd = request.getRequestDispatcher("/mainmenu.jsp");
				rd.forward(request, response);	
			}else {
				request.setAttribute("NOTIFICATION", "User Not Found!");
				rd = request.getRequestDispatcher("/SignUp.jsp");
				rd.forward(request, response);
			}
			}else {
			request.setAttribute("NOTIFICATION", "User Not Found!");
			rd = request.getRequestDispatcher("/SignUp.jsp");
			rd.forward(request, response);
			}
			}	
	}

	private void listCustomer(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());

		ProjectDAO dao = new ProjectDAO();
		List<Customer> theList = dao.getCustomer();
		request.setAttribute("customer", theList);
		RequestDispatcher rd = request.getRequestDispatcher("/SignUp.jsp");
		rd.forward(request, response);
		listProduct(request, response);
	}

	protected void saveCustomer(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		Customer c = new Customer();
		c.setCustomerId(request.getParameter("customerId"));
		c.setCustomerPhoneNo(request.getParameter("customerPhoneNo"));
		c.setCustomerName(request.getParameter("customerName"));
		c.setCustomerEmailAddress(request.getParameter("customerEmailAddress"));
		c.setCustomerPassword(request.getParameter("customerPassword"));

		if (proDAO.save(c)) {
			request.setAttribute("NOTIFICATION", "Customer Registered Successfully!");
		}
		request.setAttribute("customer", c);
		RequestDispatcher rd = request.getRequestDispatcher("/SignUp.jsp");
		rd.forward(request, response);
	}
	private void listProduct(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			response.getWriter().append("Served at: ").append(request.getContextPath());

			ProjectDAO dao = new ProjectDAO();
			List<Product> theList = dao.getProduct();
			request.setAttribute("product", theList);
			RequestDispatcher rd = request.getRequestDispatcher("/productPage.jsp");
			rd.forward(request, response);
			}
	protected void saveBookCustomer(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		Book b = new Book();
		b.setCustomerId(request.getParameter("customerId"));
		b.setProductCode(request.getParameter("productCode"));
		b.setQuantityBooked(request.getParameter("quantityBooked"));
		
		if (proDAO.saveBook(b)) {
			request.setAttribute("NOTIFICATION", "Product Booked Successfully!");
		}
		request.setAttribute("book", b);
		RequestDispatcher rd = request.getRequestDispatcher("/productBook.jsp");
		rd.forward(request, response);
	}
}
