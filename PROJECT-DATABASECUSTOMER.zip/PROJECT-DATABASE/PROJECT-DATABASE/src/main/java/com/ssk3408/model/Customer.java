package com.ssk3408.model;

public class Customer {
		String customerId;
		String customerPhoneNo;
		String customerName;
		String customerEmailAddress;
		String customerPassword;
		
		public String getCustomerPassword() {
			return customerPassword;
		}

		public void setCustomerPassword(String customerPassword) {
			this.customerPassword = customerPassword;
		}

		public String getCustomerId() {
			return customerId;
		}

		public void setCustomerId(String customerId) {
			this.customerId = customerId;
		}

		public String getCustomerPhoneNo() {
			return customerPhoneNo;
		}

		public void setCustomerPhoneNo(String customerPhoneNo) {
			this.customerPhoneNo = customerPhoneNo;
		}

		public String getCustomerName() {
			return customerName;
		}

		public void setCustomerName(String customerName) {
			this.customerName = customerName;
		}

		public String getCustomerEmailAddress() {
			return customerEmailAddress;
		}

		public void setCustomerEmailAddress(String customerEmailAddress) {
			this.customerEmailAddress = customerEmailAddress;
		}
}
