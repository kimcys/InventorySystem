package com.ssk3408.model;

public class Restock {
	String productCode;
	String quantitySupply;
	String dateSupply;
	String supplierId;
	String serialNum;
	
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getQuantitySupply() {
		return quantitySupply;
	}
	public void setQuantitySupply(String quantitySupply) {
		this.quantitySupply = quantitySupply;
	}
	public String getDateSupply() {
		return dateSupply;
	}
	public void setDateSupply(String dateSupply) {
		this.dateSupply = dateSupply;
	}
	public String getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	public String getSerialNum() {
		return serialNum;
	}
	public void setSerialNum(String serialNum) {
		this.serialNum = serialNum;
	}
	
	
}
