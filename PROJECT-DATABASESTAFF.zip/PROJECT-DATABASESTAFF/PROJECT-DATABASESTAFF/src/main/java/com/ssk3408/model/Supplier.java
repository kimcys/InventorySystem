package com.ssk3408.model;

public class Supplier {
	
	String supplierId;
	String supplierPhoneNo;
	String supplierName;
	String supplierEmailAddress;
	public String getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	public String getSupplierPhoneNo() {
		return supplierPhoneNo;
	}
	public void setSupplierPhoneNo(String supplierPhoneNo) {
		this.supplierPhoneNo = supplierPhoneNo;
	}
	public String getSupplierName() {
		return supplierName;
	}
	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}
	public String getSupplierEmailAddress() {
		return supplierEmailAddress;
	}
	public void setSupplierEmailAddress(String supplierEmailAddress) {
		this.supplierEmailAddress = supplierEmailAddress;
	}

	

}
