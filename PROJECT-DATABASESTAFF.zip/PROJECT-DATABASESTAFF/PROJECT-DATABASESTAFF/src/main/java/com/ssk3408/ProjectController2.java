package com.ssk3408;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ssk3408.DAO.ProjectDAO2;
import com.ssk3408.model.Book;
import com.ssk3408.model.Product;


public class ProjectController2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ProjectDAO2 proDAO = null;
	RequestDispatcher rd = null;
	String clickDelete = "";
	String clickUpdate = "";
	String clickLogin = "";

	public ProjectController2() {
		proDAO = new ProjectDAO2();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
		String action = request.getParameter("action");
		switch (action) {
		case "LIST":
			rd = request.getRequestDispatcher("/listproduct.jsp");
			listProduct(request, response);
			break;
		case "BOOK":
			listBook(request,response);
			break;
		case "ADD":
			rd = request.getRequestDispatcher("/AddNewProduct.jsp");
			rd.forward(request, response);
			break;
		case "SUPPLIER":
			rd = request.getRequestDispatcher("/SupplierMenu.jsp");
			rd.forward(request, response);
			break;
		case "UPDATE":
			rd = request.getRequestDispatcher("/UpdateProductInput.jsp");
			rd.forward(request, response);
			break;
		case "DELETE":
			rd = request.getRequestDispatcher("/DeleteProductInput.jsp");
			rd.forward(request, response);
			break;
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getParameter("action");
		switch (action) {
		case "ADD":
		saveProduct(request, response);
		break;
		case "UP":
		getSingleProductUpdate(request, response);
		break;
		case "DELETE":
		getSingleProductDelete(request, response);
		break;
		}	
	}
	private void listProduct(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			response.getWriter().append("Served at: ").append(request.getContextPath());

			ProjectDAO2 dao = new ProjectDAO2();
			List<Product> theList = dao.getProduct();
			request.setAttribute("product", theList);
			RequestDispatcher rd = request.getRequestDispatcher("/listproduct.jsp");
			rd.forward(request, response);
	}
	
	private void listBook(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			response.getWriter().append("Served at: ").append(request.getContextPath());

			ProjectDAO2 dao = new ProjectDAO2();
			List<Book> theList = dao.getBook();
			request.setAttribute("book", theList);
			RequestDispatcher rd = request.getRequestDispatcher("/productbooked.jsp");
			rd.forward(request, response);
	}
	
	private void getSingleProductDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());

		if (clickDelete == "") {
		String productCode = request.getParameter("product_code");
		boolean productFound = proDAO.checkProduct(productCode);

		if (productFound) {
		Product theProduct = proDAO.get(productCode);
		request.setAttribute("product", theProduct);
		clickDelete = "Display";
		rd = request.getRequestDispatcher("/DeleteProduct.jsp");
		rd.forward(request, response);
		} else {
		request.setAttribute("NOTIFICATION", "Product Not Found!");
		rd = request.getRequestDispatcher("/DeleteProductInput.jsp");
		rd.forward(request, response);
		}

		} else {
		deleteProduct(request, response);
		}
	}


	private void deleteProduct(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String productCode = request.getParameter("productCode");

		System.out.println("delete?? benarin?");
		if (proDAO.delete(productCode)) {
		request.setAttribute("NOTIFICATION", "Product Deleted Successfully!");
		clickDelete = "";
		}

		RequestDispatcher rd = request.getRequestDispatcher("/DeleteProductInput.jsp");
		rd.forward(request, response);

		}


	private void getSingleProductUpdate(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {
			response.getWriter().append("Served at: ").append(request.getContextPath());

			if (clickUpdate == "") {
			String productCode = request.getParameter("product_code");
			       boolean productFound = proDAO.checkProduct(productCode);

			if (productFound) {
			Product theProduct = proDAO.get(productCode);
			request.setAttribute("product", theProduct);
			clickUpdate = "Display";
			rd = request.getRequestDispatcher("/UpdateProduct.jsp");
			rd.forward(request, response);
			} else {
			request.setAttribute("NOTIFICATION", "Product Not Found!");
			rd = request.getRequestDispatcher("/UpdateProductInput.jsp");
			rd.forward(request, response);
			}

			} else {
			updateProduct(request, response);
			}

	}

	private void updateProduct(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException {

			Product p = new Product();
			p.setProductCode(request.getParameter("product_code"));
			p.setProductName(request.getParameter("product_name"));
			p.setProductType(request.getParameter("product_type"));
			p.setPrice(request.getParameter("price"));
			p.setQuantity(request.getParameter("quantity"));

			if (proDAO.update(p)) {
			request.setAttribute("NOTIFICATION", "Product Updated Successfully!");
			clickUpdate = "";
			}

			Product theProduct = proDAO.get(request.getParameter("product_code"));
			request.setAttribute("product", theProduct);
			RequestDispatcher rd = request.getRequestDispatcher("/UpdateProduct.jsp");
			rd.forward(request, response);

		
	}

	protected void saveProduct(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

			Product p = new Product();
			p.setProductCode(request.getParameter("productCode"));
			p.setProductName(request.getParameter("productName"));
			p.setProductType(request.getParameter("productType"));
			p.setPrice(request.getParameter("price"));
			p.setQuantity(request.getParameter("quantity"));

			if (proDAO.save(p)) {
			request.setAttribute("NOTIFICATION", "Product Registered Successfully!");
			}

			request.setAttribute("product", p);
			RequestDispatcher rd = request.getRequestDispatcher("/AddNewProduct.jsp");
			rd.forward(request, response);
			}
			}


