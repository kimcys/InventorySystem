package com.ssk3408;

import java.io.IOException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ssk3408.DAO.ProjectDAO2;
import com.ssk3408.DAO.SupplierRegisterDAO;
import com.ssk3408.model.Supplier;
import com.ssk3408.model.WorkStaff;

public class SupplierRegistrationController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	SupplierRegisterDAO supRegDAO = null;
	RequestDispatcher rd = null;
	String clickDelete = "";
	String clickUpdate = "";

	public SupplierRegistrationController() {
		supRegDAO = new SupplierRegisterDAO();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
		String action = request.getParameter("action");
		switch (action) {
		case "ADD":
			rd = request.getRequestDispatcher("/SupplierFormRegistration.jsp");
			rd.forward(request, response);
			break;
		case "EDIT":
			rd = request.getRequestDispatcher("/SupplierFormInputUpdate.jsp");
			rd.forward(request, response);
			break;
		case "DELETE":
			rd = request.getRequestDispatcher("/SupplierFormInputDelete.jsp");
			rd.forward(request, response);
			break;
		case "LIST":
			listSupplier(request, response);
			break;
		case "EXIT":
			System.exit(0);
			break;
		case "MANAGE":
			listManage(request,response);
		default:
			listSupplier(request, response);
			break;
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getParameter("action");
		switch (action) {
		case "ADD":
			saveSupplier(request, response);
			break;
		case "EDIT":
			getSingleSupplierUpdate(request, response);
			break;
		case "DELETE":
			getSingleSupplierDelete(request, response);
			break;
		default:
			listSupplier(request, response);
			break;
		}
	}

	private void listSupplier(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());

		SupplierRegisterDAO dao = new SupplierRegisterDAO();
		List<Supplier> theList = dao.getSupplier();
		request.setAttribute("supplier", theList);
		RequestDispatcher rd = request.getRequestDispatcher("/SupplierDetails.jsp");
		rd.forward(request, response);

	}

	protected void saveSupplier(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		Supplier s = new Supplier();
		s.setSupplierId(request.getParameter("supplierId"));
		s.setSupplierPhoneNo(request.getParameter("supplierPhoneNo"));
		s.setSupplierName(request.getParameter("supplierName"));
		s.setSupplierEmailAddress(request.getParameter("supplierEmailAddress"));

		if (supRegDAO.save(s)) {
			request.setAttribute("NOTIFICATION", "Supplier Registered Successfully!");
		}

		request.setAttribute("supplier", s);
		RequestDispatcher rd = request.getRequestDispatcher("/SupplierFormRegistration.jsp");
		rd.forward(request, response);
	}

	private void getSingleSupplierUpdate(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());

		if (clickUpdate == "") {
			String s = request.getParameter("supplierId");
			boolean supplierFound = supRegDAO.checkSupplier(s);

			if (supplierFound) {
				Supplier theSupplier = supRegDAO.get(s);
				request.setAttribute("supplier", theSupplier);
				clickUpdate = "Display";
				rd = request.getRequestDispatcher("/SupplierFormUpdate.jsp");
				rd.forward(request, response);
			} else {
				request.setAttribute("NOTIFICATION", "Supplier Not Found!");
				rd = request.getRequestDispatcher("/SupplierFormInputUpdate.jsp");
				rd.forward(request, response);
			}

		} else {
			updateSupplier(request, response);
		}
	}

	private void updateSupplier(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		Supplier s = new Supplier();
		s.setSupplierId(request.getParameter("supplierId"));
		s.setSupplierPhoneNo(request.getParameter("supplierPhoneNo"));
		s.setSupplierName(request.getParameter("supplierName"));
		s.setSupplierEmailAddress(request.getParameter("supplierEmailAddress"));

		if (supRegDAO.update(s)) {
			request.setAttribute("NOTIFICATION", "Supplier Updated Successfully!");
			clickUpdate = "";
		}

		Supplier supplier = supRegDAO.get(request.getParameter("supplierId"));
		request.setAttribute("supplier", supplier);
		RequestDispatcher rd = request.getRequestDispatcher("/SupplierFormUpdate.jsp");
		rd.forward(request, response);

	}

	private void getSingleSupplierDelete(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());

		if (clickDelete == "") {
			String s = request.getParameter("supplierId");
			boolean supplierFound = supRegDAO.checkSupplier(s);

			if (supplierFound) {
				Supplier theSupplier = supRegDAO.get(s);
				request.setAttribute("supplier", theSupplier);
				clickDelete = "Display";
				rd = request.getRequestDispatcher("/SupplierFormDelete.jsp");
				rd.forward(request, response);
			} else {
				request.setAttribute("NOTIFICATION", "Supplier Not Found!");
				rd = request.getRequestDispatcher("/SupplierFormInputDelete.jsp");
				rd.forward(request, response);
			}

		} else {
			deleteUser(request, response);
		}

	}
	
	private void deleteUser(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			String s = request.getParameter("supplierId");

			System.out.println("delete ni");
			if (supRegDAO.delete(s)) {
			request.setAttribute("NOTIFICATION", "Supplier Deleted Successfully!");
			clickDelete = "";
			}

			RequestDispatcher rd = request.getRequestDispatcher("/SupplierFormInputDelete.jsp");
			rd.forward(request, response);

			}

	private void listManage(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			response.getWriter().append("Served at: ").append(request.getContextPath());

			ProjectDAO2 dao = new ProjectDAO2();
			List<WorkStaff> theList = dao.getWorkStaff();
			request.setAttribute("workstaff", theList);
			RequestDispatcher rd = request.getRequestDispatcher("/manageduty.jsp");
			rd.forward(request, response);
	}
	
}
