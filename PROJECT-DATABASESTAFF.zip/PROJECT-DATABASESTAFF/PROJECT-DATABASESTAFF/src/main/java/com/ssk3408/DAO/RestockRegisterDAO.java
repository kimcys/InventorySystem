package com.ssk3408.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.ssk3408.model.Restock;

public class RestockRegisterDAO {
	Connection connection = null;
	Statement statement = null;
	ResultSet resultSet = null;
	PreparedStatement preparedStatement = null;

	public boolean save(Restock r) {
		boolean flag = false;

		try {
			String sql = "INSERT INTO restock(serialNum,supplierId, productCode, quantitySupply, dateSupply)VALUES" + "('"
					+ r.getSerialNum() + "', '" + r.getSupplierId() + "','" + r.getProductCode() + "', '" + r.getQuantitySupply() + "', '"
					+ r.getDateSupply() + "')";

			System.out.println(sql);
			connection = DBConnectionUtil.openConnection();
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.executeUpdate();
			flag = true;
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return flag;
	}

	public List<Restock> getRestock() {
		List<Restock> list = null;
		Restock restock = new Restock();

		try {
			list = new ArrayList<Restock>();
			String sql = "SELECT * FROM restock order by serialNum asc";
			connection = DBConnectionUtil.openConnection();
			statement = connection.createStatement();
			resultSet = statement.executeQuery(sql);

			while (resultSet.next()) {
				restock = new Restock();
				restock.setSerialNum(resultSet.getString("serialNum"));
				restock.setSupplierId(resultSet.getString("supplierId"));
				restock.setProductCode(resultSet.getString("productCode"));
				restock.setQuantitySupply(resultSet.getString("quantitySupply"));
				restock.setDateSupply(resultSet.getString("dateSupply"));
				list.add(restock);
			}
		} catch (Exception e) {
		}

		return list;
	}
}