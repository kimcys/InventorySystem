package com.ssk3408.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.ssk3408.model.Book;
import com.ssk3408.model.Product;
import com.ssk3408.model.WorkStaff;

public class ProjectDAO2{
	
	Connection connection = null;
	Statement statement = null;
	ResultSet resultSet = null;
	PreparedStatement preparedStatement = null;

	public List<Product> getProduct() {
		List<Product> list = null;
		Product product = new Product();

		try {
		list = new ArrayList<Product>();
		String sql = "SELECT * FROM product order by productCode asc";
		connection = DBConnectionUtil.openConnection();
		statement = connection.createStatement();
		resultSet = statement.executeQuery(sql);

		while (resultSet.next()) {
		product = new Product();
		product.setProductCode(resultSet.getString("productCode"));
		product.setProductName(resultSet.getString("productName"));
		product.setProductType(resultSet.getString("productType"));
		product.setPrice(resultSet.getString("price"));
		product.setQuantity(resultSet.getString("quantity"));
		list.add(product);
		}
		} catch (Exception e) {
		}
		return list;
		}

	public List<Book> getBook() {
	List<Book> list = null;
	Book book = new Book();

	try {
	list = new ArrayList<Book>();
	String sql = "SELECT * FROM productbooked order by productCode asc";
	connection = DBConnectionUtil.openConnection();
	statement = connection.createStatement();
	resultSet = statement.executeQuery(sql);

	while (resultSet.next()) {
	book = new Book();
	book.setCustomerId(resultSet.getString("CustomerId"));
	book.setProductCode(resultSet.getString("ProductCode"));
	book.setQuantityBooked(resultSet.getString("QuantityBooked"));
	list.add(book);
	}
	} catch (Exception e) {
	}
	return list;
	}
	
	public List<WorkStaff> getWorkStaff() {
	List<WorkStaff> list = null;
	WorkStaff workstaff = new WorkStaff();

	try {
	list = new ArrayList<WorkStaff>();
	String sql = "SELECT * FROM managestuff order by staffId asc";
	connection = DBConnectionUtil.openConnection();
	statement = connection.createStatement();
	resultSet = statement.executeQuery(sql);

	while (resultSet.next()) {
	workstaff = new WorkStaff();
	workstaff.setStaffId(resultSet.getString("StaffID"));
	workstaff.setProductCode(resultSet.getString("ProductCode"));
	workstaff.setDateManage(resultSet.getString("DateManage"));
	list.add(workstaff);
	}
	} catch (Exception e) {
	}
	return list;
	}
	
	public boolean save(Product p) {
		boolean flag = false;

		try {
			String sql = "INSERT INTO PRODUCT (productCode, productName, productType, price, quantity) VALUES" + "('"
					+ p.getProductCode() + "','" + p.getProductName() + "', '" + p.getProductType() + "', '" + p.getPrice()
					+ "', '" + p.getQuantity() + "')";

			System.out.println(sql);
			connection = DBConnectionUtil.openConnection();
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.executeUpdate();
			flag = true;
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return flag;
	}
	
	public boolean checkProduct(String productCode) {
		Boolean found = false;
		try {
		String sql = "SELECT * FROM product where productcode='" + productCode +"'";
		connection = DBConnectionUtil.openConnection();
		statement = connection.createStatement();
		resultSet = statement.executeQuery(sql);
		if (resultSet.next()) {
		found = true;
		}
		} catch (SQLException e) {
		e.printStackTrace();
		}
		return found;
}

	public Product get(String productCode) {
		Product product = null;
		try {
		product = new Product();
		String sql = "SELECT * FROM product where productcode='" + productCode +"'";
		connection = DBConnectionUtil.openConnection();
		statement = connection.createStatement();
		resultSet = statement.executeQuery(sql);
		if (resultSet.next()) {
			product.setProductCode(resultSet.getString("productCode"));
			product.setProductName(resultSet.getString("productName"));
			product.setProductType(resultSet.getString("productType"));
			product.setPrice(resultSet.getString("price"));
			product.setQuantity(resultSet.getString("quantity"));
		}
		} catch (SQLException e) {
		e.printStackTrace();
		}
		return product;
		}

	public boolean update(Product product) {
		boolean flag = false;
		try {
		String sql = "UPDATE product SET productCode ='" + product.getProductCode()  + "', productName = '" + product.getProductName() + "', "
		+ "productType = '" + product.getProductType() + "', price = '" + product.getPrice() + "', quantity = '" + product.getQuantity() + "' where productCode='"
		+ product.getProductCode() + "'";

		connection = DBConnectionUtil.openConnection();
		preparedStatement = connection.prepareStatement(sql);
		preparedStatement.executeUpdate();
		flag = true;
		} catch (SQLException e) {
		e.printStackTrace();
		}
		return flag;

	}

	public boolean delete(String productCode) {
		boolean flag = false;
	try {
		String sql = "DELETE FROM product where productcode='" + productCode +"'";
		System.out.println(sql);
		connection = DBConnectionUtil.openConnection();
		preparedStatement = connection.prepareStatement(sql);
		preparedStatement.executeUpdate();
		flag = true;
		} catch (SQLException e) {
		e.printStackTrace();
		}
		return flag;
	}
}