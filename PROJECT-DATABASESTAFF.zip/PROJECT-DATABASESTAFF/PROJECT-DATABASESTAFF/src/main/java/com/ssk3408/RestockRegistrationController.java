package com.ssk3408;


import java.io.IOException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.ssk3408.DAO.RestockRegisterDAO;
import com.ssk3408.model.Restock;

public class RestockRegistrationController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	RestockRegisterDAO resRegDAO = null;
	RequestDispatcher rd = null;
	String clickDelete = "";
	String clickUpdate = "";

	public RestockRegistrationController() {
		resRegDAO = new RestockRegisterDAO();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
		String action = request.getParameter("action");
		switch (action) {
		case "RESTOCK":
			rd = request.getRequestDispatcher("/RestockFormRegistration.jsp");
			rd.forward(request, response);
			break;
		case "EDIT":
			rd = request.getRequestDispatcher("/RestockFormInputUpdate.jsp");
			rd.forward(request, response);
			break;
		case "DELETE":
			rd = request.getRequestDispatcher("/RestockFormInputDelete.jsp");
			rd.forward(request, response);
			break;
		case "LIST":
			listRestock(request, response);
			break;
		case "EXIT":
			System.exit(0);
			break;
		default:
			listRestock(request, response);
			break;
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getParameter("action");
		switch (action) {
		case "RESTOCK":
			saveRestock(request, response);
			break;
		default:
			listRestock(request, response);
			break;
		}
	}

	private void listRestock(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());

		RestockRegisterDAO dao = new RestockRegisterDAO();
		List<Restock> theList = dao.getRestock();
		request.setAttribute("restock", theList);
		RequestDispatcher rd = request.getRequestDispatcher("/RestockFormList.jsp");
		rd.forward(request, response);

	}

	protected void saveRestock(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		Restock r = new Restock();
		r.setSerialNum(request.getParameter("serialNum"));
		r.setSupplierId(request.getParameter("supplierId"));
		r.setProductCode(request.getParameter("productCode"));
		r.setQuantitySupply(request.getParameter("quantitySupply"));
		r.setDateSupply(request.getParameter("dateSupply"));

		if (resRegDAO.save(r)) {
			request.setAttribute("NOTIFICATION", "Restock Registered Successfully!");
		}

		request.setAttribute("restock", r);
		RequestDispatcher rd = request.getRequestDispatcher("/RestockFormRegistration.jsp");
		rd.forward(request, response);
	}
}