package com.ssk3408.model;

public class WorkStaff {

	String staffId;
	String productCode;
	String dateManage;
	
	public String getStaffId() {
		return staffId;
	}
	public void setStaffId(String staffId) {
		this.staffId = staffId;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getDateManage() {
		return dateManage;
	}
	public void setDateManage(String dateManage) {
		this.dateManage = dateManage;
	}

	
}