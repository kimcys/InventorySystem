package com.ssk3408.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.ssk3408.model.Supplier;

public class SupplierRegisterDAO {
	Connection connection = null;
	Statement statement = null;
	ResultSet resultSet = null;
	PreparedStatement preparedStatement = null;

	public boolean save(Supplier s) {
		boolean flag = false;

		try {
			String sql = "INSERT INTO supplier(supplierid, supplierphoneno, suppliername, supplieremailaddress)VALUES"
					+ "('" + s.getSupplierId() + "','" + s.getSupplierPhoneNo() + "', '" + s.getSupplierName() + "', '"
					+ s.getSupplierEmailAddress() + "')";

			System.out.println(sql);
			connection = DBConnectionUtil.openConnection();
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.executeUpdate();
			flag = true;
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return flag;
	}

	public List<Supplier> getSupplier() {
		List<Supplier> list = null;
		Supplier supplier = new Supplier();

		try {
			list = new ArrayList<Supplier>();
			String sql = "SELECT * FROM supplier order by supplierid asc";
			connection = DBConnectionUtil.openConnection();
			statement = connection.createStatement();
			resultSet = statement.executeQuery(sql);

			while (resultSet.next()) {
				supplier = new Supplier();
				supplier.setSupplierId(resultSet.getString("supplierId"));
				supplier.setSupplierPhoneNo(resultSet.getString("supplierPhoneNo"));
				supplier.setSupplierName(resultSet.getString("supplierName"));
				supplier.setSupplierEmailAddress(resultSet.getString("supplierEmailAddress"));

				list.add(supplier);
			}
		} catch (Exception e) {
		}

		return list;
	}

	public boolean checkSupplier(String supplierId) {
		Boolean found = false;
		try {
			String sql = "SELECT * FROM supplier where supplierId='" + supplierId + "'";
			connection = DBConnectionUtil.openConnection();
			statement = connection.createStatement();
			resultSet = statement.executeQuery(sql);
			if (resultSet.next()) {
				found = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return found;
	}

	public Supplier get(String supplierId) {
		Supplier supplier = null;
		try {
			supplier = new Supplier();
			String sql = "SELECT * FROM supplier where supplierId='" + supplierId + "'";
			connection = DBConnectionUtil.openConnection();
			statement = connection.createStatement();
			resultSet = statement.executeQuery(sql);
			if (resultSet.next()) {
				supplier.setSupplierId(resultSet.getString("supplierId"));
				supplier.setSupplierPhoneNo(resultSet.getString("supplierPhoneNo"));
				supplier.setSupplierName(resultSet.getString("supplierName"));
				supplier.setSupplierEmailAddress(resultSet.getString("supplierEmailAddress"));

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return supplier;
	}

	public boolean update(Supplier supplier) {
		boolean flag = false;
		try {
			String sql = "UPDATE supplier SET supplierId ='" + supplier.getSupplierId() + "', supplierphoneno = '"
					+ supplier.getSupplierPhoneNo() + "', " + "suppliername = '" + supplier.getSupplierName()
					+ "', supplieremailaddress = '" + supplier.getSupplierEmailAddress() + "' where supplierId ='"
					+ supplier.getSupplierId() + "'";

			connection = DBConnectionUtil.openConnection();
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.executeUpdate();
			flag = true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return flag;
	}

	public boolean delete(String s) {
		boolean flag = false;
		try {
			String sql = "DELETE FROM supplier where supplierId='" + s + "'";
			System.out.println(sql);
			connection = DBConnectionUtil.openConnection();
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.executeUpdate();
			flag = true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return flag;
	}

}
